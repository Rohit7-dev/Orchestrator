import classNames = require('./index.js');
export = classNames;
